//package Project.HotelManagementSystemA.Service;
//
//import java.util.List;
//
//import Project.HotelManagementSystemA.Model.Room;
//
//public interface RoomService {
//	
//	List<Room> findAll();
//
//	void createRoom(Room room);
//
//	void deleteRoom(Long roomId);
//
//	void updateRoom(Room room);
//
//}
