//package Project.HotelManagementSystemA.ServiceImpl;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import Project.HotelManagementSystemA.Model.Room;
//import Project.HotelManagementSystemA.Repo.RoomRepository;
//import Project.HotelManagementSystemA.Service.RoomService;
//
//@Service
//public class RoomServiceImpl implements RoomService{
//
//
//	@Autowired
//	private RoomRepository roomrepository;
//
//	@Override
//	public List<Room> findAll() {
//		System.out.println("Inside findAll() method of RoomServiceImpl");
//		return roomrepository.findAll();
//	}
//
//	@Override
//	public void createRoom(Room room) {
//		System.out.println("Inside createHotel() method of RoomServiceImpl");
//		roomrepository.save(room);
//	}
//
//	@Override
//	public void deleteRoom(Long roomId) {
//		System.out.println("Inside deleteHotel() method of RoomServiceImpl");
//		roomrepository.deleteById(roomId);
//	}
//
//	@Override
//	public void updateRoom(Room room) {
//		
//		System.out.println("Inside updateHotel() method of RoomServiceImpl");
//		//repos.deleteById(room.getId());
//		roomrepository.save(room);
//	}
//	
//}
