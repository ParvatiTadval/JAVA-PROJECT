//package Project.HotelManagementSystemA.Repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import Project.HotelManagementSystemA.Model.Room;
//
//public interface RoomRepository extends JpaRepository<Room, Long>{
//
//}
