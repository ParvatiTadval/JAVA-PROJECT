package Project.HotelManagementSystemA.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import Project.HotelManagementSystemA.Model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	public Customer findByUsername (String username);

}
