package Project.HotelManagementSystemA;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class HotelManagementSystemAApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(HotelManagementSystemAApplication.class, args);
		System.out.println("Project is OK!");

		
	}

}
