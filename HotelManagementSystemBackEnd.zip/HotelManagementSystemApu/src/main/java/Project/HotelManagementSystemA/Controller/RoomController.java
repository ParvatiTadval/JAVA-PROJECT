//package Project.HotelManagementSystemA.Controller;
//
//import java.util.List;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import Project.HotelManagementSystemA.Model.Room;
//import Project.HotelManagementSystemA.Service.RoomService;
//
//@RestController
//@RequestMapping("/room")
//@CrossOrigin("*")
//public class RoomController {
//	@Autowired
//	private RoomService service;
//	
//	private static final Logger logger = LoggerFactory.getLogger(RoomController.class);
//	
//	//get all rooms
//	//@GetMapping("/rooms")
//	@GetMapping("/")
//	public List<Room> findAll(){
//		logger.info("Inside findAll() method of RoomController");
//		return service.findAll();
//	}
//	
//	//create record
//	//@PostMapping("/room/add")
//	@PostMapping("/")
//	public void createRoom(@RequestBody Room room) {
//		logger.info("Inside createRoom() method of RoomController");
//		service.createRoom(room);
//	}
//	
//	//delete record
//	//@DeleteMapping("/delete/{roomId}")
//	@DeleteMapping("/{roomid}")
//	public void deleteRoom(@PathVariable Long roomId) {
//		logger.info("Inside deleteRoom() method of RoomController");
//		service.deleteRoom(roomId);
//	}
//	
//	
//	//update record
//	//@PutMapping("/room/update")
//	@PutMapping("/update")
//	public void updateRoom(@RequestBody Room room) {
//		logger.info("Inside updateRoom() method of RoomController");
//		service.updateRoom(room);
//	}
//	
//}
