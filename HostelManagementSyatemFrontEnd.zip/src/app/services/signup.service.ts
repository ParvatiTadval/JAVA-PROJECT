import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private httpClient:HttpClient) { }

   //add customer
   public addCustomer(customer:any)
   {
      return this.httpClient.post(`${baseUrl}/customer/`,customer)
   }
}
