import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AdmincrudService } from 'src/app/services/admincrud.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-admincrud',
  templateUrl: './admincrud.component.html',
  styleUrls: ['./admincrud.component.css']
})
export class AdmincrudComponent implements OnInit{
  
  public customer:any;

  constructor(private admincrudService: AdmincrudService, private snack:MatSnackBar, private router: Router)
  { 
    this.getAllCustomerDetails();
  }

//  public customerData:any;

  ngOnInit(): void {}

  getAllCustomerDetails()
  {
    this.admincrudService.getAllCustomerDetails().subscribe
    (
      (resp)=>{
        //success
        Swal.fire('Profile Displayed Successfully!');
        console.log(resp);
        this.customer=resp;
      },
      (error:any)=>{
        //error
        console.log(error);
        alert("Something went wrong!");
      }
    );
  }

  deleteCustomerDetails(customerid: number){
    this.admincrudService.deleteCustomer(customerid).subscribe(
      (resp)=>{
        //success
        Swal.fire('Selected record deleted successfully!');
        console.log(resp);
        this.customer=resp;
        //this.router.navigate(["/"]);
      },
      (error:any)=>{
        //error
        console.log(error);
        alert("Something went wrong!");
      }
    )
  }

  updateCustomerDetails(customer:any){
    this.admincrudService.updateCustomer(customer).subscribe(
      (resp)=>{
        Swal.fire('Customer details updated successfully!');
        console.log(resp);
        this.customer=resp;
        this.router.navigate(["/"]);
      },
      (error:any)=>{
        //error
        console.log(error);
        alert("Something went wrong!");
      }
    );
  }
  

}

